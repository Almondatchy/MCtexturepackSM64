// 0x06020A04
const struct Animation *const whomp_seg6_anims_06020A04[] = {
    &whomp_seg6_anim_060209EC,
    &whomp_seg6_anim_060202DC,
};
