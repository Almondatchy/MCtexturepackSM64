// 0x16000388
const GeoLayout warp_pipe_geo[] = {
   GEO_CULLING_RADIUS(350),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, warp_pipe_seg3_dl_03008F98),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, warp_pipe_seg3_dl_03009A50),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
