#include "anim_0600A4BC.inc.c"
