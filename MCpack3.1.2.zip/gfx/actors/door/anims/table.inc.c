// 0x030156C0
const struct Animation *const door_seg3_anims_030156C0[] = {
    &door_seg3_anim_03015208,
    &door_seg3_anim_03015440,
    &door_seg3_anim_03015690,
    &door_seg3_anim_03015458,
    &door_seg3_anim_030156A8,
    NULL,
};
